package com.example.alcoolougasolina;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private TextView txtResultado;
    private EditText edtAlcool, edtGasolina;
    private  Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtResultado = findViewById(R.id.txt_resultado);
        edtAlcool    = findViewById(R.id.edt_alcool);
        edtGasolina  = findViewById(R.id.edt_gasosa);
        btnCalcular  = findViewById(R.id.btn_calcular);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularPreco();
            }
        });
    }

    private void calcularPreco() {
        String precoAlcool = edtAlcool.getText().toString();
        String precoGasolina = edtGasolina.getText().toString();

        //validar campos

        boolean camposValidados = validarCampos(precoAlcool, precoGasolina);
            if (!camposValidados){
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            }else{
                double valorAlcool = Double.parseDouble(precoAlcool);
                double valorGasolina = Double.parseDouble(precoGasolina);
                double resultado = valorAlcool/valorGasolina;

                if(resultado >= .7){
                    txtResultado.setTextColor(getResources().getColor(R.color.corGasolina));
                    txtResultado.setText("Melhor usar gasosa");
                }else{
                    txtResultado.setText("Melhor usar alcool memo");
                    txtResultado.setTextColor(getResources().getColor(R.color.corAlcool));
                }
            }
    }

    private boolean validarCampos(String pAlcool, String pGasolina) {
        boolean camposValidados = true;
        if (pAlcool == null || pAlcool.equals("")){
            camposValidados = false;
        }
        if (pGasolina == null || pGasolina.equals("")){
            camposValidados = false;
        }
        return camposValidados;
    }
}
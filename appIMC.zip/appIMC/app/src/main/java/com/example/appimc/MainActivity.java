package com.example.appimc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    private TextView resultado;
    private EditText peso,altura;
    private Button btnCalcular;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resultado = findViewById(R.id.txtResultado);
        peso = findViewById(R.id.peso);
        altura = findViewById(R.id.altura);
        btnCalcular = findViewById(R.id.button);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularImc();
            }
        });
        }

        private void calcularImc(){
        String peso2 = peso.getText().toString();
        String altura2 = altura.getText().toString();
        String base = "00.00";
        double altura1 = Double.parseDouble(altura2);
        double peso1 = Double.parseDouble(peso2);
        double imc = peso1/(altura1*altura1);
        DecimalFormat dc = new DecimalFormat("##.##");
        if (imc < 18.5){
            resultado.setText("Abaixo do peso: " + imc);
        }else if (imc > 18.5 && imc < 24.9){
            resultado.setText("Peso normal: " + imc);
        }else if (imc > 25 && imc < 29.9){
            resultado.setText("Sobrepeso: " + imc);
        }else if (imc > 39 && imc < 39.9){
            resultado.setText("Obesidade: " + imc);
        }else if(imc > 40){
                resultado.setText("Obesidade morbida: " + imc);
            }


    }
}